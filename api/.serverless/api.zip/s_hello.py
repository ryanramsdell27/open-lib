import serverless_sdk
sdk = serverless_sdk.SDK(
    tenant_id='payton',
    application_name='lib',
    app_uid='5slHK7ckMMkhF6rYmG',
    tenant_uid='7pkYgdqZ6XyZWj4rLr',
    deployment_uid='2caeb33e-63e7-4b1d-b63c-c98ec2fda06e',
    service_name='api',
    stage_name='dev',
    plugin_version='3.1.2'
)
handler_wrapper_kwargs = {'function_name': 'api-dev-hello', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('handler.hello')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
